<script setup>
import {
    computed,
    ref,
    watch,
    onErrorCaptured,
    onMounted,
    onBeforeUnmount,
    nextTick,
} from "vue";
import { useForm, Head, router } from "@inertiajs/vue3";
import MainLayout from "@/Layouts/MainLayout.vue";

// Definisikan props dengan nilai default agar tidak error jika data dari backend kosong
const props = defineProps({
    pegawai: {
        type: Array,
        default: () => [],
    },
    // Daftar unik Kelompok Substansi dari database (dikirim AdminController@kelolaPegawai)
    daftarKelompok: {
        type: Array,
        default: () => [],
    },
    // Daftar unik Tim Kerja dari seluruh kelompok (dikirim AdminController@kelolaPegawai)
    daftarTimKerja: {
        type: Array,
        default: () => [],
    },
    // Pemetaan { "Nama Kelompok": ["Tim A", "Tim B"] } untuk dropdown Tim Kerja
    timPerKelompok: {
        type: [Object, Array],
        default: () => ({}),
    },
    // Kelompok yang tidak punya tim kerja (Tim Kerja dikunci di form)
    daftarKelompokTanpaTim: {
        type: Array,
        default: () => [],
    },
    // Daftar jabatan fungsional STAF (dropdown Jabatan untuk role Karyawan/Staf)
    daftarJabatanFungsional: {
        type: Array,
        default: () => [],
    },
    // Versi berkelompok per rumpun: [{ label, options: [...] }] (opsional, dari controller).
    // Kalau kosong, dropdown jabatan memakai daftar datar di atas.
    daftarJabatanFungsionalGrup: {
        type: Array,
        default: () => [],
    },
    // Jabatan tetap per role_id: { 4: "Kepala Subbagian Tata Usaha", 6: "Kepala Biro Perencanaan" }
    jabatanTetap: {
        type: [Object, Array],
        default: () => ({}),
    },
    // Jabatan fungsional yang dipakai Ketua (dropdown "Ubah jabatan fungsional")
    daftarJabatanKetua: {
        type: Array,
        default: () => [],
    },
    // Versi berkelompok untuk jabatan Ketua (opsional, dari controller)
    daftarJabatanKetuaGrup: {
        type: Array,
        default: () => [],
    },
    // Jabatan fungsional bawaan tiap Ketua: { "Tim Kerja X": "Perencana Ahli Muda", ... }
    jabatanKetuaDefault: {
        type: [Object, Array],
        default: () => ({}),
    },
});

// ---> SISTEM PENDETEKSI ERROR OTOMATIS <---
const vueError = ref(null);
onErrorCaptured((err) => {
    vueError.value = err.toString();
    console.error("VUE ERROR TERTANGKAP:", err);
    return false; // Mencegah error merusak seluruh halaman
});

const formatRole = (roleId) => {
    const roles = {
        1: "Karyawan",
        2: "Atasan L1",
        3: "Atasan L2",
        4: "Atasan L3",
        5: "Admin SDM",
        6: "Atasan L4",
    };
    return roles[roleId] || "Tidak Diketahui";
};

// ===================== FITUR SEARCH + FILTER + PAGINATION =====================
const searchNama = ref("");
const selectedKelompokSubstansi = ref("");
// Filter status kepegawaian (bawaan: hanya yang Aktif)
const selectedStatus = ref("Aktif");
// Harus sama dengan STATUS_PEGAWAI di AdminController
const daftarStatus = [
    "Aktif",
    "Pensiun",
    "Mutasi Keluar",
    "Resign / Berhenti",
    "Meninggal Dunia",
];
const currentPage = ref(1);
const itemsPerPage = 10;

const filteredPegawai = computed(() => {
    const keyword = searchNama.value.trim().toLowerCase();

    return props.pegawai.filter((item) => {
        const nama = (item?.nama || "").toLowerCase();
        const nip = String(item?.nip || "").toLowerCase();
        const kelompokSubstansi = item?.kelompok_substansi || "";
        const status = item?.status_aktif || "Aktif";

        return (
            (!keyword || nama.includes(keyword) || nip.includes(keyword)) &&
            (!selectedKelompokSubstansi.value ||
                kelompokSubstansi === selectedKelompokSubstansi.value) &&
            (!selectedStatus.value || status === selectedStatus.value)
        );
    });
});

const daftarKelompokSubstansi = computed(() =>
    [
        ...new Set(
            props.pegawai
                .map((item) => item?.kelompok_substansi)
                .filter(Boolean),
        ),
    ].sort((a, b) => a.localeCompare(b)),
);

const totalPages = computed(() =>
    Math.max(1, Math.ceil(filteredPegawai.value.length / itemsPerPage)),
);

const paginatedPegawai = computed(() => {
    const start = (currentPage.value - 1) * itemsPerPage;
    return filteredPegawai.value.slice(start, start + itemsPerPage);
});

watch([searchNama, selectedKelompokSubstansi, selectedStatus], () => {
    currentPage.value = 1;
});

// Daftar nomor halaman yang ditampilkan (dengan "..." jika halaman banyak)
// Contoh: 1 ... 4 5 6 ... 10
const halamanTampil = computed(() => {
    const total = totalPages.value;
    const cur = currentPage.value;

    if (total <= 7) {
        return Array.from({ length: total }, (_, i) => i + 1);
    }

    const pages = [1];
    const start = Math.max(2, cur - 1);
    const end = Math.min(total - 1, cur + 1);

    if (start > 2) pages.push("...");
    for (let i = start; i <= end; i++) pages.push(i);
    if (end < total - 1) pages.push("...");
    pages.push(total);

    return pages;
});

const goToPage = (page) => {
    currentPage.value = Math.min(Math.max(page, 1), totalPages.value);
};
// ===================== END SEARCH + FILTER + PAGINATION =====================

// State reaktivitas modal
const isModalOpen = ref(false);
const isEditMode = ref(false);
const currentEditId = ref(null);

const form = useForm({
    nip: "",
    nama: "",
    jabatan: "",
    kelompok_substansi: "",
    tim_kerja: "",
    role_id: 1,
    no_telepon: "",
    alamat_domisili: "",
    status_aktif: "Aktif",
});

// ===================== DROPDOWN KELOMPOK SUBSTANSI & TIM KERJA (FORM) =====================
// Nilai khusus pada dropdown untuk memunculkan input teks (menambah pilihan baru)
const OPSI_BARU = "__opsi_baru__";

// Jika true, field tampil sebagai input teks biasa (untuk mengetik nilai baru)
const kelompokModeBaru = ref(false);
const timKerjaModeBaru = ref(false);

// Bandingkan teks tanpa peduli huruf besar/kecil & spasi berlebih
const samaTeks = (a, b) =>
    String(a ?? "").trim().toLowerCase() === String(b ?? "").trim().toLowerCase();

// Cari nilai di daftar opsi (abaikan huruf besar/kecil). Kalau ketemu, pakai
// penulisan dari daftar; kalau tidak, kembalikan nilai aslinya.
const samakanDenganOpsi = (nilai, daftar) =>
    (daftar || []).find((opsi) => samaTeks(opsi, nilai)) ?? (nilai || "");

// Opsi Kelompok Substansi = daftar dari controller (struktur resmi Biro +
// kelompok yang ada di database). Kalau props kosong, pakai data pegawai.
// Nilai yang sedang dipilih ditambahkan agar data lama tetap tampil saat edit.
const opsiKelompokForm = computed(() => {
    const hasil = props.daftarKelompok.length
        ? [...props.daftarKelompok]
        : [...daftarKelompokSubstansi.value];

    const nilai = form.kelompok_substansi;
    if (nilai && !hasil.some((opsi) => samaTeks(opsi, nilai))) {
        hasil.push(nilai);
    }

    return hasil;
});

// Opsi Tim Kerja = tim milik kelompok yang sedang dipilih.
// Sumber utama: timPerKelompok dari controller. Kalau props kosong, pakai
// data pegawai. Nilai yang sedang dipilih ditambahkan agar tidak hilang.
const opsiTimKerjaForm = computed(() => {
    const hasil = [];
    const tambah = (tim) => {
        if (tim && !hasil.some((opsi) => samaTeks(opsi, tim))) {
            hasil.push(tim);
        }
    };

    const dariServer = props.timPerKelompok?.[form.kelompok_substansi];
    if (Array.isArray(dariServer)) {
        dariServer.forEach(tambah);
    } else {
        props.pegawai.forEach((item) => {
            if (item?.kelompok_substansi === form.kelompok_substansi) {
                tambah(item?.tim_kerja);
            }
        });
    }

    tambah(form.tim_kerja);

    return hasil;
});

// True jika kelompok yang dipilih memang tidak punya tim kerja
// (mis. Subbagian Tata Usaha) -> kolom Tim Kerja dikunci.
const kelompokTanpaTim = computed(() => {
    if (kelompokModeBaru.value || !form.kelompok_substansi) return false;
    return props.daftarKelompokTanpaTim.some((k) =>
        samaTeks(k, form.kelompok_substansi),
    );
});

const onKelompokChange = (event) => {
    resetFungsionalKetua();
    const value = event.target.value;

    if (value === OPSI_BARU) {
        kelompokModeBaru.value = true;
        form.kelompok_substansi = "";
    } else {
        form.kelompok_substansi = value;
    }

    // Ganti kelompok => pilihan tim kerja sebelumnya tidak berlaku lagi
    form.tim_kerja = "";
    timKerjaModeBaru.value = false;
};

const onTimKerjaChange = (event) => {
    resetFungsionalKetua();
    const value = event.target.value;

    if (value === OPSI_BARU) {
        timKerjaModeBaru.value = true;
        form.tim_kerja = "";
    } else {
        form.tim_kerja = value;
    }
};

// Kembali dari input teks ke dropdown
const kembaliKeDropdownKelompok = () => {
    resetFungsionalKetua();
    kelompokModeBaru.value = false;
    form.kelompok_substansi = "";
    form.tim_kerja = "";
    timKerjaModeBaru.value = false;
};

const kembaliKeDropdownTimKerja = () => {
    resetFungsionalKetua();
    timKerjaModeBaru.value = false;
    form.tim_kerja = "";
};

const resetModeDropdown = () => {
    kelompokModeBaru.value = false;
    timKerjaModeBaru.value = false;
    resetJabatan();
};
// ===================== END DROPDOWN KELOMPOK & TIM KERJA =====================

// ===================== DROPDOWN JABATAN & ATURAN ROLE (FORM) =====================
// Bentuk isian jabatan mengikuti Hak Akses (role):
//   1 = staf (pilih dari daftar), 2 = Ketua Tim, 3 = Ketua Kelompok,
//   4 / 6 = jabatan tetap (Kasubag TU / Kepala Biro), lainnya = teks bebas.
const roleAktif = computed(() => Number(form.role_id));

const jabatanJenis = computed(() => {
    const r = roleAktif.value;
    if (r === 1) return "staf";
    if (r === 2) return "ketua_tim";
    if (r === 3) return "ketua_kelompok";
    if (props.jabatanTetap?.[r]) return "tetap";
    return "bebas";
});

const perluAwalan = computed(() =>
    ["ketua_tim", "ketua_kelompok"].includes(jabatanJenis.value),
);

// Pilihan dropdown (nama jabatan fungsional) atau OPSI_BARU ("Lainnya")
const jabatanPilihan = ref("");
// Teks ketikan sendiri (untuk "Lainnya" atau role Admin)
const jabatanTeks = ref("");
// True jika admin memilih mengubah jabatan fungsional Ketua dari bawaan Excel
const ubahFungsional = ref(false);

// Awalan otomatis untuk Ketua: "Ketua Tim Kerja X / " atau "Ketua Kelompok Y / "
const awalanJabatan = computed(() => {
    if (jabatanJenis.value === "ketua_tim") {
        const tim = String(form.tim_kerja || "").trim();
        return tim ? `Ketua ${tim} / ` : "";
    }
    if (jabatanJenis.value === "ketua_kelompok") {
        const kelompok = String(form.kelompok_substansi || "").trim();
        return kelompok ? `Ketua ${kelompok} / ` : "";
    }
    return "";
});

// Jabatan fungsional bawaan Ketua menurut Excel (dicari dari nama Tim / Kelompok)
const fungsionalBawaan = computed(() => {
    let kunci = "";
    if (jabatanJenis.value === "ketua_tim") kunci = form.tim_kerja;
    if (jabatanJenis.value === "ketua_kelompok") kunci = form.kelompok_substansi;
    if (!kunci) return "";

    const entri = Object.entries(props.jabatanKetuaDefault || {}).find(
        ([nama]) => samaTeks(nama, kunci),
    );
    return entri ? entri[1] : "";
});

// True = Ketua memakai jabatan fungsional bawaan (tanpa dropdown)
const pakaiBawaan = computed(
    () =>
        perluAwalan.value &&
        !!fungsionalBawaan.value &&
        !ubahFungsional.value,
);

// Opsi dropdown: Ketua hanya 4 jabatan fungsional, staf memakai daftar penuh
const opsiFungsional = computed(() =>
    perluAwalan.value
        ? props.daftarJabatanKetua
        : props.daftarJabatanFungsional,
);

const bagianJabatan = computed(() => {
    if (pakaiBawaan.value) return fungsionalBawaan.value;
    return jabatanPilihan.value === OPSI_BARU
        ? jabatanTeks.value.trim()
        : jabatanPilihan.value;
});

// Nilai akhir yang dikirim ke server
const jabatanGabungan = computed(() => {
    switch (jabatanJenis.value) {
        case "tetap":
            return props.jabatanTetap?.[roleAktif.value] || "";
        case "bebas":
            return jabatanTeks.value.trim();
        case "staf":
            return bagianJabatan.value;
        default: // ketua_tim / ketua_kelompok
            return awalanJabatan.value && bagianJabatan.value
                ? awalanJabatan.value + bagianJabatan.value
                : "";
    }
});

// Jaga form.jabatan selalu sama dengan hasil gabungan
watch(jabatanGabungan, (nilai) => {
    form.jabatan = nilai;
});

// Salah ketik yang pernah masuk dari Excel -> penulisan yang benar
const ALIAS_JABATAN = {
    "perencan ahli pertama": "Perencana Ahli Pertama",
};

const cocokkanFungsional = (teks, daftar) => {
    const bersih = String(teks ?? "").trim();
    const nilai = ALIAS_JABATAN[bersih.toLowerCase()] || bersih;
    return (daftar || []).find((opsi) => samaTeks(opsi, nilai)) ?? null;
};

const resetJabatan = () => {
    jabatanPilihan.value = "";
    jabatanTeks.value = "";
    ubahFungsional.value = false;
    dropdownJabatanBuka.value = false;
};

// Dipanggil saat Tim Kerja / Kelompok berganti: Ketua kembali ke jabatan
// fungsional bawaan tim/kelompok yang baru. Jabatan staf tidak ikut direset.
const resetFungsionalKetua = () => {
    if (!perluAwalan.value) return;
    resetJabatan();
};

const kembaliKeBawaan = () => resetJabatan();

// Isi state jabatan dari jabatan lama (dipanggil saat Edit, SETELAH role,
// kelompok & tim kerja terisi).
const muatJabatan = (jabatanLama) => {
    resetJabatan();

    const teks = String(jabatanLama || "").trim();
    const jenis = jabatanJenis.value;

    if (jenis === "tetap") return;
    if (jenis === "bebas") {
        jabatanTeks.value = teks;
        return;
    }

    let bagian = teks;

    if (jenis !== "staf") {
        const awalan = awalanJabatan.value;
        if (awalan && teks.toLowerCase().startsWith(awalan.toLowerCase())) {
            bagian = teks.slice(awalan.length);
        } else if (teks.includes(" / ")) {
            // Data lama yang awalannya beda penulisan: ambil bagian sesudah " / "
            bagian = teks.slice(teks.lastIndexOf(" / ") + 3);
        }
    }

    if (!bagian) return;

    const cocok = cocokkanFungsional(bagian, opsiFungsional.value);

    if (jenis !== "staf") {
        // Sama dengan bawaan Excel -> tidak perlu dianggap "diubah"
        if (cocok && samaTeks(cocok, fungsionalBawaan.value)) return;
        ubahFungsional.value = true;
    }

    if (cocok) {
        jabatanPilihan.value = cocok;
    } else {
        jabatanPilihan.value = OPSI_BARU;
        jabatanTeks.value = bagian;
    }
};

// ---> Aturan struktur menurut Hak Akses (sesuai Excel) <---
//   Kepala Biro (6)     : tanpa Kelompok & Tim Kerja
//   Kasubag TU (4)      : Kelompok otomatis "Subbagian Tata Usaha", tanpa Tim Kerja
//   Ketua Kelompok (3)  : tanpa Tim Kerja
const NAMA_KELOMPOK_TU = "Subbagian Tata Usaha";

const timDikunciRole = computed(() => [3, 4, 6].includes(roleAktif.value));
const timTerkunci = computed(
    () => kelompokTanpaTim.value || timDikunciRole.value,
);
const pesanTimTerkunci = computed(() =>
    timDikunciRole.value
        ? "Posisi ini tidak memiliki tim kerja"
        : "Kelompok ini tidak memiliki tim kerja",
);

const terapkanAturanRole = () => {
    const r = roleAktif.value;

    if (r === 6) {
        kelompokModeBaru.value = false;
        timKerjaModeBaru.value = false;
        form.kelompok_substansi = "";
        form.tim_kerja = "";
    } else if (r === 4) {
        kelompokModeBaru.value = false;
        timKerjaModeBaru.value = false;
        form.kelompok_substansi = NAMA_KELOMPOK_TU;
        form.tim_kerja = "";
    } else if (r === 3) {
        timKerjaModeBaru.value = false;
        form.tim_kerja = "";
    }
};

// Ganti role => isian jabatan sebelumnya tidak berlaku lagi
const onRoleChange = () => {
    resetJabatan();
    terapkanAturanRole();
};
// ===================== END DROPDOWN JABATAN =====================

// ===================== DROPDOWN JABATAN CUSTOM (SCROLL + MAX-HEIGHT) =====================
// Pengganti <select> bawaan browser untuk pilihan Jabatan. <select> native tidak
// bisa dibatasi tingginya lewat CSS sehingga daftar yang panjang menutupi
// tombol lain. Di sini daftarnya berupa kotak melayang (absolute) dengan
// max-h-60 + overflow-y-auto, jadi tidak mendorong/merusak susunan form.
const dropdownJabatanBuka = ref(false);
const dropdownJabatanRef = ref(null); // pembungkus (untuk deteksi klik di luar)
const daftarJabatanRef = ref(null); // kotak daftar (untuk scroll ke tampilan)

// Tombol dikunci saat Ketua belum memilih Tim Kerja / Kelompok
const jabatanDisabled = computed(
    () => perluAwalan.value && !awalanJabatan.value,
);

// Teks yang tampil di tombol pemicu
const labelJabatanPilihan = computed(() =>
    jabatanPilihan.value === OPSI_BARU
        ? "Lainnya (ketik sendiri)..."
        : jabatanPilihan.value,
);

// Opsi untuk kotak daftar, selalu dalam bentuk grup [{ label, options }].
// Memakai versi berkelompok dari controller kalau ada; kalau tidak, seluruh
// opsi dimasukkan ke satu grup tanpa label (tampil sebagai daftar biasa).
const opsiGrupJabatan = computed(() => {
    const grup = perluAwalan.value
        ? props.daftarJabatanKetuaGrup
        : props.daftarJabatanFungsionalGrup;

    if (Array.isArray(grup) && grup.length) return grup;

    return [{ label: "", options: opsiFungsional.value }];
});

// Judul grup hanya ditampilkan kalau memang ada lebih dari satu grup berlabel
const tampilkanJudulGrup = computed(
    () =>
        opsiGrupJabatan.value.length > 1 &&
        opsiGrupJabatan.value.some((g) => g.label),
);

const toggleDropdownJabatan = () => {
    if (jabatanDisabled.value) return;
    dropdownJabatanBuka.value = !dropdownJabatanBuka.value;
};

const pilihJabatan = (nilai) => {
    jabatanPilihan.value = nilai;
    dropdownJabatanBuka.value = false;
};

// Saat daftar terbuka, pastikan seluruh kotaknya kelihatan di dalam modal
watch(dropdownJabatanBuka, (buka) => {
    if (!buka) return;
    nextTick(() => {
        daftarJabatanRef.value?.scrollIntoView({
            block: "nearest",
            behavior: "smooth",
        });
    });
});

// Tutup daftar kalau pengguna mengklik di luar komponen
const tutupJikaKlikDiLuar = (event) => {
    if (
        dropdownJabatanBuka.value &&
        dropdownJabatanRef.value &&
        !dropdownJabatanRef.value.contains(event.target)
    ) {
        dropdownJabatanBuka.value = false;
    }
};

onMounted(() => document.addEventListener("mousedown", tutupJikaKlikDiLuar));
onBeforeUnmount(() =>
    document.removeEventListener("mousedown", tutupJikaKlikDiLuar),
);
// ===================== END DROPDOWN JABATAN CUSTOM =====================

// ---> HELPER VALIDASI: class input berubah merah jika ada error dari Laravel <---
const inputClass = (field) => [
    "mt-1 block w-full rounded-md shadow-sm",
    form.errors[field]
        ? "border-red-500 focus:border-red-500 focus:ring-red-500"
        : "border-gray-300 focus:border-indigo-500 focus:ring-indigo-500",
];

// Jumlah field yang error (untuk banner ringkasan di atas form)
const jumlahError = computed(() => Object.keys(form.errors).length);

// Fungsi buka modal Tambah
const openAddModal = () => {
    isEditMode.value = false;
    currentEditId.value = null;
    form.reset();
    form.clearErrors();
    resetModeDropdown();
    isModalOpen.value = true;
};

// Fungsi buka modal Edit
const openEditModal = (item) => {
    isEditMode.value = true;
    currentEditId.value = item.id;
    form.clearErrors();
    resetModeDropdown();
    form.nip = item.nip || "";
    form.nama = item.nama || "";
    form.jabatan = item.jabatan || "";
    // Samakan penulisan data lama (mis. "Tim Kerja Anggaran Ii") dengan opsi
    // dropdown ("... II") supaya pilihan yang benar langsung terpilih.
    form.kelompok_substansi = samakanDenganOpsi(
        item.kelompok_substansi,
        props.daftarKelompok,
    );
    form.tim_kerja = samakanDenganOpsi(
        item.tim_kerja,
        props.timPerKelompok?.[form.kelompok_substansi],
    );
    // Data lama di kelompok tanpa tim: kosongkan supaya konsisten dengan kunci
    if (kelompokTanpaTim.value) form.tim_kerja = "";
    form.role_id = item.role_id || 1;
    form.no_telepon = item.no_telepon || "";
    form.alamat_domisili = item.alamat_domisili || "";
    form.status_aktif = item.status_aktif || "Aktif";

    // Terapkan aturan role (mis. Kepala Biro: kosongkan kelompok "-" dari data lama)
    terapkanAturanRole();

    // Isi dropdown jabatan dari data lama (setelah role, kelompok & tim terisi)
    muatJabatan(item.jabatan);
    form.jabatan = jabatanGabungan.value;

    isModalOpen.value = true;
};

// Fungsi tutup modal form (bersihkan error agar tidak muncul lagi saat dibuka ulang)
const closeModal = () => {
    isModalOpen.value = false;
    form.clearErrors();
    resetModeDropdown();
};

// Fungsi simpan (Store / Update)
const submitForm = () => {
    form.jabatan = jabatanGabungan.value;

    if (isEditMode.value) {
        form.put(route("admin.pegawai.update", currentEditId.value), {
            preserveScroll: true,
            onSuccess: () => {
                isModalOpen.value = false;
                form.reset();
                resetModeDropdown();
            },
            // Modal tetap terbuka & pesan error tampil di bawah tiap input
            onError: (errors) => {
                console.warn("Validasi gagal:", errors);
            },
        });
    } else {
        form.post(route("admin.pegawai.store"), {
            preserveScroll: true,
            onSuccess: () => {
                isModalOpen.value = false;
                form.reset();
                resetModeDropdown();
            },
            onError: (errors) => {
                console.warn("Validasi gagal:", errors);
            },
        });
    }
};

// ---> STATE UNTUK TOAST NOTIFIKASI SUKSES RESET PASSWORD <---
const showResetToast = ref(false);
const resetToastNama = ref("");
let resetToastTimer = null;

// ---> STATE UNTUK TOAST NOTIFIKASI ERROR (reset password / hapus gagal) <---
const showErrorToast = ref(false);
const errorToastMessage = ref("");
let errorToastTimer = null;

const tampilkanErrorToast = (errors) => {
    const pesan = Object.values(errors || {})[0];
    errorToastMessage.value =
        pesan || "Terjadi kesalahan. Silakan coba lagi.";
    showErrorToast.value = true;
    clearTimeout(errorToastTimer);
    errorToastTimer = setTimeout(() => {
        showErrorToast.value = false;
    }, 5000);
};

// ========================================== //
// ---> FITUR: RESET PASSWORD PEGAWAI <---
// ========================================== //
const showModalReset = ref(false);
const pegawaiYangAkanDireset = ref(null);

const konfirmasiReset = (item) => {
    pegawaiYangAkanDireset.value = item;
    showModalReset.value = true;
};

const batalReset = () => {
    showModalReset.value = false;
    pegawaiYangAkanDireset.value = null;
};

const eksekusiReset = () => {
    if (!pegawaiYangAkanDireset.value) return;

    const item = pegawaiYangAkanDireset.value;

    router.post(
        route("admin.pegawai.reset-password", item.id),
        {},
        {
            preserveScroll: true,
            onSuccess: () => {
                showModalReset.value = false;
                pegawaiYangAkanDireset.value = null;

                resetToastNama.value = item.nama;
                showResetToast.value = true;
                clearTimeout(resetToastTimer);
                resetToastTimer = setTimeout(() => {
                    showResetToast.value = false;
                }, 3500);
            },
            onError: (errors) => {
                showModalReset.value = false;
                pegawaiYangAkanDireset.value = null;
                tampilkanErrorToast(errors);
            },
        },
    );
};

// ========================================== //
// ---> FITUR: HAPUS DATA PEGAWAI (SOFT DELETE) <---
// ========================================== //
const showModalHapus = ref(false);
const pegawaiYangAkanDihapus = ref(null);

const konfirmasiHapus = (item) => {
    pegawaiYangAkanDihapus.value = item;
    showModalHapus.value = true;
};

const batalHapus = () => {
    showModalHapus.value = false;
    pegawaiYangAkanDihapus.value = null;
};

const eksekusiHapus = () => {
    if (!pegawaiYangAkanDihapus.value) return;

    router.delete(
        route("admin.pegawai.destroy", pegawaiYangAkanDihapus.value.id),
        {
            preserveScroll: true,
            onSuccess: () => {
                showModalHapus.value = false;
                pegawaiYangAkanDihapus.value = null;
            },
            onError: (errors) => {
                showModalHapus.value = false;
                pegawaiYangAkanDihapus.value = null;
                tampilkanErrorToast(errors);
            },
        },
    );
};

// ========================================== //
// ---> FITUR: IMPOR DATA PEGAWAI <---
// ========================================== //
const isImportModalOpen = ref(false);

const importForm = useForm({
    file: null,
});

const importFileInput = ref(null);

const openImportModal = () => {
    importForm.reset();
    importForm.clearErrors();
    isImportModalOpen.value = true;
};

const closeImportModal = () => {
    isImportModalOpen.value = false;
    importForm.reset();
    importForm.clearErrors();
    if (importFileInput.value) {
        importFileInput.value.value = null;
    }
};

const handleImportFileChange = (event) => {
    importForm.file = event.target.files[0] ?? null;
    importForm.clearErrors();
};

const submitImportForm = () => {
    if (!importForm.file) return;

    importForm.post(route("admin.pegawai.import"), {
        forceFormData: true,
        onSuccess: () => {
            closeImportModal();
        },
    });
};
</script>

<template>
    <Head title="Kelola Pegawai" />

    <MainLayout>
        <div>
            <!-- KOTAK MERAH PENDETEKSI ERROR -->
            <div
                v-if="vueError"
                class="bg-red-600 text-white p-6 rounded-lg mb-6 shadow-xl font-mono text-sm border-4 border-red-800"
            >
                <h2 class="text-xl font-black mb-2">
                    🚨 VUE RENDER ERROR TERTANGKAP!
                </h2>
                <p>
                    Pesan Error: <strong>{{ vueError }}</strong>
                </p>
                <p class="mt-2 text-xs opacity-80">
                    Silakan kirimkan tulisan error di atas kepada saya agar kita
                    perbaiki akarnya!
                </p>
            </div>

            <!-- KONTEN UTAMA -->
            <div
                v-else
                class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 relative z-10"
            >
                <!-- ================= HEADER HALAMAN ================= -->
                <div
                    class="flex flex-col md:flex-row md:justify-between md:items-center mb-6 border-b pb-4 gap-4"
                >
                    <div>
                        <h2 class="text-2xl font-bold text-gray-800">
                            Master Data Pegawai
                        </h2>
                        <p class="text-sm text-gray-500 mt-1">
                            Kelola data induk seluruh pegawai dan hak aksesnya.
                            Untuk kuota &amp; saldo cuti, kelola melalui menu
                            <span class="font-medium text-gray-600"
                                >Rekap Kuota Detail</span
                            >.
                        </p>
                    </div>

                    <!-- Kontainer tombol aksi -->
                    <div class="flex flex-wrap items-center justify-end gap-3">
                        <div
                            class="inline-flex h-12 min-w-[170px] items-center justify-center gap-3 rounded-lg border border-indigo-100 bg-indigo-50 px-4 text-indigo-900 shadow-sm"
                        >
                            <span
                                class="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-sm font-bold text-white"
                            >
                                {{ filteredPegawai.length }}
                            </span>
                            <span
                                class="text-sm font-semibold whitespace-nowrap"
                            >
                                Total Pegawai
                            </span>
                        </div>

                        <!-- Tombol Impor Data: biru -->
                        <button
                            type="button"
                            @click="openImportModal"
                            class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 border border-transparent rounded-full font-semibold text-sm text-white hover:bg-blue-700 transition ease-in-out duration-150 shadow-sm cursor-pointer"
                        >
                            <svg
                                class="w-4 h-4"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
                                />
                            </svg>
                            Impor Data
                        </button>

                        <!-- Tombol Tambah Pegawai: ungu/violet -->
                        <button
                            type="button"
                            @click="openAddModal"
                            class="px-5 py-2.5 bg-violet-600 text-white rounded-full text-sm font-extrabold hover:bg-violet-700 cursor-pointer shadow-lg hover:scale-105 transition-all"
                        >
                            + Tambah Pegawai
                        </button>
                    </div>
                </div>

                <!-- ================= BARIS FILTER & PENCARIAN (UI BARU) ================= -->
                <div class="mb-5 flex flex-col sm:flex-row sm:flex-wrap items-center gap-3">
                    <!-- Search Input dengan Icon -->
                    <div class="relative min-w-0 flex-1 w-full">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <svg class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                        </div>
                        <input
                            id="cari-pegawai-admin"
                            name="cari_pegawai"
                            v-model="searchNama"
                            type="text"
                            placeholder="Cari nama atau NIP..."
                            aria-label="Cari nama atau NIP"
                            class="min-h-[44px] pl-10 pr-10 w-full rounded-lg border-gray-300 shadow-sm text-base sm:text-sm focus:border-indigo-500 focus:ring-indigo-500 transition-colors"
                        />
                        <button
                            v-if="searchNama"
                            type="button"
                            @click="searchNama = ''"
                            aria-label="Hapus pencarian"
                            class="absolute inset-y-0 right-0 min-h-[44px] min-w-[44px] px-3 flex items-center justify-center text-gray-400 hover:text-gray-700 cursor-pointer transition-colors"
                        >
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <!-- Dropdown Filter dengan Ikon -->
                    <div class="relative w-full sm:w-auto shrink-0">
                        <!-- Ikon Filter di sebelah kiri -->
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                            </svg>
                        </div>
                        <select
                            id="filter-kelompok-pegawai-admin"
                            name="kelompok_substansi"
                            v-model="selectedKelompokSubstansi"
                            aria-label="Filter kelompok substansi"
                            class="min-h-[44px] pl-9 w-full sm:w-auto min-w-0 sm:min-w-[220px] rounded-lg border-gray-300 shadow-sm text-base sm:text-sm text-gray-700 focus:border-indigo-500 focus:ring-indigo-500 transition-colors cursor-pointer"
                        >
                            <option value="">Semua Kelompok</option>
                            <option
                                v-for="kelompokSubstansi in daftarKelompokSubstansi"
                                :key="kelompokSubstansi"
                                :value="kelompokSubstansi"
                            >
                                {{ kelompokSubstansi }}
                            </option>
                        </select>
                    </div>

                    <!-- Dropdown Filter Status Kepegawaian -->
                    <div class="relative w-full sm:w-auto shrink-0">
                        <select
                            id="filter-status-pegawai-admin"
                            name="status"
                            v-model="selectedStatus"
                            aria-label="Filter status pegawai"
                            class="min-h-[44px] w-full sm:w-auto min-w-[180px] rounded-lg border-gray-300 shadow-sm text-base sm:text-sm text-gray-700 focus:border-indigo-500 focus:ring-indigo-500 transition-colors cursor-pointer"
                        >
                            <option value="">Semua Status</option>
                            <option
                                v-for="status in daftarStatus"
                                :key="status"
                                :value="status"
                            >
                                {{ status }}
                            </option>
                        </select>
                    </div>
                </div>

                <!-- Penanda filter kelompok yang sedang aktif -->
                <div v-if="selectedKelompokSubstansi" class="flex items-center gap-2 mb-4 text-xs">
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold shadow-sm">
                        {{ selectedKelompokSubstansi }}
                        <button
                            type="button"
                            @click="selectedKelompokSubstansi = ''"
                            class="hover:text-indigo-900 cursor-pointer"
                            title="Hapus filter kelompok"
                        >
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </span>
                    <span class="text-gray-500">{{ filteredPegawai.length }} pegawai ditemukan</span>
                </div>
                <!-- ================= END BARIS FILTER & PENCARIAN ================= -->

                <div class="hidden overflow-x-auto md:block">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    NIP
                                </th>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    Nama Pegawai
                                </th>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    Kelompok Substansi
                                </th>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    Tim Kerja
                                </th>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    Jabatan
                                </th>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    Hak Akses
                                </th>
                                <th
                                    class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase"
                                >
                                    Status
                                </th>
                                <th
                                    class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase"
                                >
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <tr v-if="!pegawai || pegawai.length === 0">
                                <td
                                    colspan="8"
                                    class="px-6 py-12 text-center text-gray-500 font-bold bg-gray-50/50"
                                >
                                    <span class="block text-xl mb-2">📭</span>
                                    Data Pegawai Kosong atau Belum Dimasukkan
                                </td>
                            </tr>
                            <tr v-else-if="filteredPegawai.length === 0">
                                <td
                                    colspan="8"
                                    class="px-6 py-12 text-center text-gray-500 font-bold bg-gray-50/50"
                                >
                                    Tidak ada pegawai yang sesuai dengan filter
                                    saat ini
                                </td>
                            </tr>
                            <tr
                                v-else
                                v-for="item in paginatedPegawai"
                                :key="item.id"
                                class="hover:bg-gray-50"
                            >
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm text-gray-900"
                                >
                                    {{ item?.nip || "-" }}
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm text-gray-900 font-medium"
                                >
                                    <div
                                        class="max-w-[220px] truncate"
                                        :title="item?.nama || '-'"
                                    >
                                        {{ item?.nama || "-" }}
                                    </div>
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm text-gray-500"
                                >
                                    {{ item?.kelompok_substansi || "-" }}
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm text-gray-500"
                                >
                                    {{ item?.tim_kerja || "-" }}
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm text-gray-500"
                                >
                                    <div
                                        class="max-w-[220px] truncate"
                                        :title="item?.jabatan || '-'"
                                    >
                                        {{ item?.jabatan || "-" }}
                                    </div>
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm text-gray-500"
                                >
                                    {{ formatRole(item?.role_id) }}
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm"
                                >
                                    <span
                                        class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold"
                                        :class="
                                            (item?.status_aktif || 'Aktif') === 'Aktif'
                                                ? 'bg-green-100 text-green-700'
                                                : 'bg-gray-200 text-gray-600'
                                        "
                                    >
                                        {{ item?.status_aktif || "Aktif" }}
                                    </span>
                                </td>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm font-medium"
                                >
                                    <div
                                        class="flex items-center justify-center gap-2"
                                    >
                                        <!-- Edit -->
                                        <button
                                            type="button"
                                            @click="openEditModal(item)"
                                            title="Edit Pegawai"
                                            class="p-2 bg-blue-50 text-blue-600 rounded-full hover:bg-blue-100 hover:text-blue-700 transition-colors shadow-sm cursor-pointer"
                                        >
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke-width="1.5"
                                                stroke="currentColor"
                                                class="w-4 h-4"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125"
                                                />
                                            </svg>
                                        </button>

                                        <!-- Reset Password -->
                                        <button
                                            type="button"
                                            @click="konfirmasiReset(item)"
                                            title="Atur Ulang Kata Sandi"
                                            class="p-2 bg-orange-50 text-orange-600 rounded-full hover:bg-orange-100 hover:text-orange-700 transition-colors shadow-sm cursor-pointer"
                                        >
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke-width="1.5"
                                                stroke="currentColor"
                                                class="w-4 h-4"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1.001.43-1.563A6 6 0 1121.75 8.25z"
                                                />
                                            </svg>
                                        </button>

                                        <!-- Hapus -->
                                        <button
                                            type="button"
                                            @click="konfirmasiHapus(item)"
                                            title="Hapus Pegawai"
                                            class="p-2 bg-red-50 text-red-600 rounded-full hover:bg-red-100 hover:text-red-700 transition-colors shadow-sm cursor-pointer"
                                        >
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke-width="1.5"
                                                stroke="currentColor"
                                                class="w-4 h-4"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                                                />
                                            </svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="space-y-3 md:hidden">
                    <article
                        v-for="item in paginatedPegawai"
                        :key="item.id"
                        class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"
                    >
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <h3 class="break-words font-semibold text-gray-900">{{ item?.nama || "-" }}</h3>
                                <p class="mt-1 break-words text-xs text-gray-500">{{ item?.nip || "-" }}</p>
                            </div>
                            <span
                                class="shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold"
                                :class="(item?.status_aktif || 'Aktif') === 'Aktif' ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-600'"
                            >
                                {{ item?.status_aktif || "Aktif" }}
                            </span>
                        </div>
                        <dl class="mt-3 space-y-2 text-sm">
                            <div class="flex justify-between gap-3">
                                <dt class="text-gray-500">Kelompok substansi</dt>
                                <dd class="break-words text-right text-gray-800">{{ item?.kelompok_substansi || "-" }}</dd>
                            </div>
                            <div class="flex justify-between gap-3">
                                <dt class="text-gray-500">Tim kerja</dt>
                                <dd class="break-words text-right text-gray-800">{{ item?.tim_kerja || "-" }}</dd>
                            </div>
                            <div class="flex justify-between gap-3">
                                <dt class="text-gray-500">Jabatan</dt>
                                <dd class="break-words text-right text-gray-800">{{ item?.jabatan || "-" }}</dd>
                            </div>
                            <div class="flex justify-between gap-3">
                                <dt class="text-gray-500">Hak akses</dt>
                                <dd class="break-words text-right text-gray-800">{{ formatRole(item?.role_id) }}</dd>
                            </div>
                        </dl>
                        <div class="mt-4 grid grid-cols-3 gap-2">
                            <button
                                type="button"
                                @click="openEditModal(item)"
                                :aria-label="`Ubah data ${item?.nama || 'pegawai'}`"
                                class="min-h-[44px] rounded-lg bg-blue-50 px-2 py-2 text-xs font-semibold text-blue-700"
                            >
                                Ubah
                            </button>
                            <button
                                type="button"
                                @click="konfirmasiReset(item)"
                                :aria-label="`Atur ulang kata sandi ${item?.nama || 'pegawai'}`"
                                class="min-h-[44px] rounded-lg bg-orange-50 px-2 py-2 text-xs font-semibold text-orange-700"
                            >
                                Atur ulang sandi
                            </button>
                            <button
                                type="button"
                                @click="konfirmasiHapus(item)"
                                :aria-label="`Hapus ${item?.nama || 'pegawai'}`"
                                class="min-h-[44px] rounded-lg bg-red-50 px-2 py-2 text-xs font-semibold text-red-700"
                            >
                                Hapus
                            </button>
                        </div>
                    </article>
                    <p
                        v-if="!pegawai || pegawai.length === 0"
                        class="rounded-xl border border-gray-200 bg-gray-50 px-4 py-8 text-center text-sm font-semibold text-gray-500"
                    >
                        Data pegawai kosong atau belum dimasukkan.
                    </p>
                    <p
                        v-else-if="filteredPegawai.length === 0"
                        class="rounded-xl border border-gray-200 bg-gray-50 px-4 py-8 text-center text-sm font-semibold text-gray-500"
                    >
                        Tidak ada pegawai yang sesuai dengan filter saat ini.
                    </p>
                </div>

                <!-- PAGINATION -->
                <div
                    v-if="filteredPegawai.length > 0"
                    class="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-gray-200 pt-4"
                >
                    <span class="text-sm text-gray-500">
                        Halaman {{ currentPage }} dari {{ totalPages }} ({{
                            filteredPegawai.length
                        }}
                        data)
                    </span>
                    <nav class="flex flex-wrap items-center gap-1" aria-label="Navigasi halaman">
                        <button
                            type="button"
                            @click="goToPage(currentPage - 1)"
                            :disabled="currentPage === 1"
                            class="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:cursor-not-allowed disabled:text-gray-400 disabled:hover:bg-white cursor-pointer"
                        >
                            &laquo; Sebelumnya
                        </button>

                        <template
                            v-for="(halaman, idx) in halamanTampil"
                            :key="`halaman-${idx}`"
                        >
                            <span
                                v-if="halaman === '...'"
                                class="px-2 text-sm text-gray-400 select-none"
                            >
                                &hellip;
                            </span>
                            <button
                                v-else
                                type="button"
                                @click="goToPage(halaman)"
                                :aria-current="halaman === currentPage ? 'page' : undefined"
                                class="min-w-[2.25rem] rounded-md border px-3 py-1.5 text-sm font-medium cursor-pointer transition-colors"
                                :class="
                                    halaman === currentPage
                                        ? 'border-blue-600 bg-blue-600 text-white'
                                        : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
                                "
                            >
                                {{ halaman }}
                            </button>
                        </template>

                        <button
                            type="button"
                            @click="goToPage(currentPage + 1)"
                            :disabled="currentPage === totalPages"
                            class="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:cursor-not-allowed disabled:text-gray-400 disabled:hover:bg-white cursor-pointer"
                        >
                            Berikutnya &raquo;
                        </button>
                    </nav>
                </div>
            </div>

            <!-- ========================================== -->
            <!-- MODAL FORM EDIT / TAMBAH PEGAWAI           -->
            <!-- ========================================== -->
            <Teleport to="body">
                <div
                    v-if="isModalOpen"
                    class="fixed inset-0 flex items-end justify-center p-0 sm:items-center sm:p-4"
                    style="z-index: 999999"
                >
                    <div
                        class="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        @click="closeModal"
                    ></div>

                    <div
                        class="relative bg-white p-4 sm:p-6 rounded-t-2xl sm:rounded-xl w-full max-w-2xl shadow-2xl max-h-[90dvh] overflow-y-auto z-10"
                    >
                        <div
                            class="flex justify-between items-center mb-5 border-b pb-3"
                        >
                            <h3 class="text-lg font-bold text-gray-800">
                                {{
                                    isEditMode
                                        ? "Edit Data Pegawai"
                                        : "Tambah Data Pegawai Baru"
                                }}
                            </h3>
                            <button
                                type="button"
                                @click="closeModal"
                                class="text-gray-400 hover:text-red-500 font-bold text-2xl cursor-pointer outline-none"
                            >
                                &times;
                            </button>
                        </div>

                        <!-- BANNER RINGKASAN ERROR VALIDASI -->
                        <div
                            v-if="jumlahError > 0"
                            class="mb-4 flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3"
                            role="alert"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                class="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
                                />
                            </svg>
                            <p class="text-sm text-red-700">
                                Data belum bisa disimpan. Periksa
                                <span class="font-semibold"
                                    >{{ jumlahError }} isian</span
                                >
                                yang ditandai merah di bawah ini.
                            </p>
                        </div>

                        <form @submit.prevent="submitForm">
                            <p
                                class="text-xs font-bold uppercase tracking-wide text-gray-400 mb-3"
                            >
                                Identitas & Kontak
                            </p>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
                                <div>
                                    <label
                                        for="pegawai-nip"
                                        class="block text-sm font-medium text-gray-700"
                                        >NIP <span class="text-red-500">*</span></label
                                    >
                                    <input
                                        id="pegawai-nip"
                                        name="nip"
                                        type="text"
                                        v-model="form.nip"
                                        required
                                        maxlength="18"
                                        inputmode="numeric"
                                        placeholder="18 digit angka"
                                        :class="['min-h-[44px] text-base sm:text-sm', inputClass('nip')]"
                                    />
                                    <p
                                        v-if="form.errors.nip"
                                        class="mt-1 text-xs text-red-600"
                                    >
                                        {{ form.errors.nip }}
                                    </p>
                                </div>
                                <div>
                                    <label
                                        for="pegawai-nama"
                                        class="block text-sm font-medium text-gray-700"
                                        >Nama Lengkap & Gelar <span class="text-red-500">*</span></label
                                    >
                                    <input
                                        id="pegawai-nama"
                                        name="nama"
                                        type="text"
                                        v-model="form.nama"
                                        required
                                        :class="['min-h-[44px] text-base sm:text-sm', inputClass('nama')]"
                                    />
                                    <p
                                        v-if="form.errors.nama"
                                        class="mt-1 text-xs text-red-600"
                                    >
                                        {{ form.errors.nama }}
                                    </p>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
                                <div>
                                    <label
                                        for="pegawai-telepon"
                                        class="block text-sm font-medium text-gray-700"
                                        >No Telepon</label
                                    >
                                    <input
                                        id="pegawai-telepon"
                                        name="no_telepon"
                                        type="text"
                                        v-model="form.no_telepon"
                                        placeholder="08xxxxxxxxxx"
                                        :class="['min-h-[44px] text-base sm:text-sm', inputClass('no_telepon')]"
                                    />
                                    <p
                                        v-if="form.errors.no_telepon"
                                        class="mt-1 text-xs text-red-600"
                                    >
                                        {{ form.errors.no_telepon }}
                                    </p>
                                </div>
                                <div>
                                    <label
                                        for="pegawai-role"
                                        class="block text-sm font-medium text-gray-700"
                                        >Hak Akses (Role) <span class="text-red-500">*</span></label
                                    >
                                    <select
                                        id="pegawai-role"
                                        name="role_id"
                                        v-model="form.role_id"
                                        @change="onRoleChange"
                                        required
                                        :class="['min-h-[44px] text-base sm:text-sm', inputClass('role_id')]"
                                    >
                                        <option value="1">
                                            Karyawan / Staf
                                        </option>
                                        <option value="2">
                                            Atasan L1 (Ketua Tim Kerja)
                                        </option>
                                        <option value="3">
                                            Atasan L2 (Ketua Kelompok)
                                        </option>
                                        <option value="4">
                                            Atasan L3 (Kasubag TU)
                                        </option>
                                        <option value="5">Admin SDM</option>
                                        <option value="6">
                                            Atasan L4 (Kepala Biro)
                                        </option>
                                    </select>
                                    <p
                                        v-if="form.errors.role_id"
                                        class="mt-1 text-xs text-red-600"
                                    >
                                        {{ form.errors.role_id }}
                                    </p>
                                </div>
                            </div>

                            <div class="mb-5">
                                <label
                                    for="pegawai-alamat"
                                    class="block text-sm font-medium text-gray-700"
                                    >Alamat</label
                                >
                                <textarea
                                    id="pegawai-alamat"
                                    name="alamat_domisili"
                                    v-model="form.alamat_domisili"
                                    rows="2"
                                    :class="['min-h-[72px] text-base sm:text-sm', inputClass('alamat_domisili')]"
                                ></textarea>
                                <p
                                    v-if="form.errors.alamat_domisili"
                                    class="mt-1 text-xs text-red-600"
                                >
                                    {{ form.errors.alamat_domisili }}
                                </p>
                            </div>

                            <div class="border-t border-gray-100 pt-4 mb-2">
                                <p
                                    class="text-xs font-bold uppercase tracking-wide text-gray-400 mb-3"
                                >
                                    Posisi & Jabatan
                                </p>

                                <div
                                    class="grid grid-cols-1 md:grid-cols-2 gap-4"
                                >
                                    <!-- KELOMPOK SUBSTANSI: dropdown (atau input teks jika menambah baru) -->
                                    <div>
                                        <label for="kelompok-substansi-pegawai" class="block text-sm font-medium text-gray-700"
                                            >Kelompok Substansi
                                            <span v-if="roleAktif !== 6" class="text-red-500">*</span></label
                                        >

                                        <!-- Kepala Biro: tidak punya kelompok -->
                                        <input
                                            v-if="roleAktif === 6"
                                            id="kelompok-substansi-pegawai"
                                            name="kelompok_substansi"
                                            type="text"
                                            disabled
                                            value="Kepala Biro tidak memiliki kelompok"
                                            class="mt-1 block w-full rounded-md border-gray-300 bg-gray-100 text-gray-400 shadow-sm cursor-not-allowed"
                                        />

                                        <select
                                            id="kelompok-substansi-pegawai"
                                            name="kelompok_substansi"
                                            v-else-if="!kelompokModeBaru"
                                            :value="form.kelompok_substansi"
                                            @change="onKelompokChange"
                                            :disabled="roleAktif === 4"
                                            required
                                            :class="[
                                                inputClass('kelompok_substansi'),
                                                'disabled:bg-gray-100 disabled:text-gray-500 disabled:cursor-not-allowed',
                                            ]"
                                        >
                                            <option value="">-- Pilih Kelompok --</option>
                                            <option
                                                v-for="kelompok in opsiKelompokForm"
                                                :key="kelompok"
                                                :value="kelompok"
                                            >
                                                {{ kelompok }}
                                            </option>
                                            <option :value="OPSI_BARU">+ Tambah kelompok baru...</option>
                                        </select>

                                        <div v-else>
                                            <input
                                                id="kelompok-substansi-pegawai"
                                                name="kelompok_substansi"
                                                type="text"
                                                v-model="form.kelompok_substansi"
                                                required
                                                placeholder="Ketik nama kelompok baru"
                                                :class="inputClass('kelompok_substansi')"
                                            />
                                            <button
                                                type="button"
                                                @click="kembaliKeDropdownKelompok"
                                                class="mt-1 text-xs text-indigo-600 hover:text-indigo-800 cursor-pointer"
                                            >
                                                &laquo; Kembali ke daftar pilihan
                                            </button>
                                        </div>

                                        <p
                                            v-if="form.errors.kelompok_substansi"
                                            class="mt-1 text-xs text-red-600"
                                        >
                                            {{ form.errors.kelompok_substansi }}
                                        </p>
                                    </div>

                                    <!-- TIM KERJA: dropdown bergantung pada kelompok yang dipilih -->
                                    <div>
                                        <label
                                            for="tim-kerja-pegawai"
                                            class="block text-sm font-medium text-gray-700"
                                            >Tim Kerja</label
                                        >

                                        <!-- Terkunci: kelompok ini tidak punya tim kerja / posisi ini tanpa tim -->
                                        <input
                                            v-if="timTerkunci"
                                            id="tim-kerja-pegawai"
                                            name="tim_kerja"
                                            type="text"
                                            disabled
                                            :value="pesanTimTerkunci"
                                            class="mt-1 block w-full rounded-md border-gray-300 bg-gray-100 text-gray-400 shadow-sm cursor-not-allowed"
                                        />

                                        <select
                                            id="tim-kerja-pegawai"
                                            name="tim_kerja"
                                            v-else-if="!timKerjaModeBaru"
                                            :value="form.tim_kerja"
                                            @change="onTimKerjaChange"
                                            :disabled="!form.kelompok_substansi"
                                            :class="[
                                                inputClass('tim_kerja'),
                                                'disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed',
                                            ]"
                                        >
                                            <option value="">
                                                {{
                                                    !form.kelompok_substansi
                                                        ? "Pilih kelompok dulu"
                                                        : opsiTimKerjaForm.length
                                                          ? "-- Pilih Tim Kerja --"
                                                          : "-- Tidak ada tim kerja --"
                                                }}
                                            </option>
                                            <option
                                                v-for="tim in opsiTimKerjaForm"
                                                :key="tim"
                                                :value="tim"
                                            >
                                                {{ tim }}
                                            </option>
                                            <option :value="OPSI_BARU">+ Tambah tim kerja baru...</option>
                                        </select>

                                        <div v-else>
                                            <input
                                                id="tim-kerja-pegawai"
                                                name="tim_kerja"
                                                type="text"
                                                v-model="form.tim_kerja"
                                                placeholder="Ketik nama tim kerja baru"
                                                :class="inputClass('tim_kerja')"
                                            />
                                            <button
                                                type="button"
                                                @click="kembaliKeDropdownTimKerja"
                                                class="mt-1 text-xs text-indigo-600 hover:text-indigo-800 cursor-pointer"
                                            >
                                                &laquo; Kembali ke daftar pilihan
                                            </button>
                                        </div>

                                        <p
                                            v-if="form.errors.tim_kerja"
                                            class="mt-1 text-xs text-red-600"
                                        >
                                            {{ form.errors.tim_kerja }}
                                        </p>
                                    </div>
                                </div>

                                <!-- JABATAN: bentuk isian mengikuti Hak Akses -->
                                <div class="mt-4">
                                    <label
                                        for="jabatan-pegawai"
                                        class="block text-sm font-medium text-gray-700"
                                        >Jabatan <span class="text-red-500">*</span></label
                                    >

                                    <!-- Kasubag TU / Kepala Biro: terisi otomatis -->
                                    <input
                                        v-if="jabatanJenis === 'tetap'"
                                        id="jabatan-pegawai"
                                        name="jabatan"
                                        type="text"
                                        disabled
                                        :value="jabatanGabungan"
                                        class="mt-1 block w-full rounded-md border-gray-300 bg-gray-100 text-gray-500 shadow-sm cursor-not-allowed"
                                    />

                                    <!-- Admin: teks bebas -->
                                    <input
                                        v-else-if="jabatanJenis === 'bebas'"
                                        id="jabatan-pegawai"
                                        name="jabatan"
                                        type="text"
                                        v-model="jabatanTeks"
                                        required
                                        :class="inputClass('jabatan')"
                                    />

                                    <!-- Staf / Ketua Tim / Ketua Kelompok -->
                                    <template v-else>
                                        <p
                                            v-if="perluAwalan && !awalanJabatan"
                                            class="mt-1 text-xs text-amber-600"
                                        >
                                            {{
                                                jabatanJenis === "ketua_tim"
                                                    ? "Pilih Tim Kerja terlebih dahulu."
                                                    : "Pilih Kelompok Substansi terlebih dahulu."
                                            }}
                                        </p>

                                        <!-- Ketua: jabatan lengkap terisi otomatis sesuai Excel -->
                                        <div v-if="pakaiBawaan">
                                            <p
                                                class="mt-1 rounded-md border border-gray-200 bg-gray-100 px-3 py-2 text-sm text-gray-700 break-words"
                                            >
                                                {{ jabatanGabungan }}
                                            </p>
                                            <button
                                                type="button"
                                                @click="ubahFungsional = true"
                                                class="mt-1 text-xs text-indigo-600 hover:text-indigo-800 cursor-pointer"
                                            >
                                                Ubah jabatan fungsional
                                            </button>
                                        </div>

                                        <!-- Staf, atau Ketua yang jabatan fungsionalnya diubah / tidak punya bawaan -->
                                        <template v-else>
                                            <p
                                                v-if="perluAwalan && awalanJabatan"
                                                class="mt-1 rounded-md border border-gray-200 bg-gray-100 px-3 py-2 text-sm text-gray-600 break-words"
                                            >
                                                {{ awalanJabatan }}
                                            </p>

                                            <!-- DROPDOWN JABATAN CUSTOM: kotak melayang, max-h-60 + scroll -->
                                            <div
                                                ref="dropdownJabatanRef"
                                                class="relative"
                                                @keydown.esc.stop="dropdownJabatanBuka = false"
                                            >
                                                <!-- Tombol pemicu (tampil seperti input) -->
                                                <button
                                                    type="button"
                                                    @click="toggleDropdownJabatan"
                                                    :disabled="jabatanDisabled"
                                                    aria-haspopup="listbox"
                                                    :aria-expanded="dropdownJabatanBuka"
                                                    :class="[
                                                        'mt-1 flex w-full items-center justify-between gap-2 rounded-md border bg-white px-3 py-2 text-left shadow-sm cursor-pointer focus:outline-none focus:ring-1 disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed',
                                                        form.errors.jabatan
                                                            ? 'border-red-500 focus:border-red-500 focus:ring-red-500'
                                                            : 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500',
                                                    ]"
                                                >
                                                    <span
                                                        class="truncate"
                                                        :class="
                                                            jabatanPilihan
                                                                ? 'text-gray-900'
                                                                : 'text-gray-500'
                                                        "
                                                    >
                                                        {{
                                                            labelJabatanPilihan ||
                                                            "-- Pilih Jabatan --"
                                                        }}
                                                    </span>
                                                    <svg
                                                        class="h-4 w-4 flex-shrink-0 text-gray-400 transition-transform"
                                                        :class="{ 'rotate-180': dropdownJabatanBuka }"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            stroke-width="2"
                                                            d="M19 9l-7 7-7-7"
                                                        />
                                                    </svg>
                                                </button>

                                                <!-- Kotak daftar melayang -->
                                                <div
                                                    v-if="dropdownJabatanBuka"
                                                    ref="daftarJabatanRef"
                                                    role="listbox"
                                                    class="absolute z-50 mt-1 w-full max-h-60 overflow-y-auto rounded-md border border-gray-300 bg-white shadow-lg"
                                                >
                                                    <!-- Kosongkan pilihan -->
                                                    <button
                                                        type="button"
                                                        role="option"
                                                        @click="pilihJabatan('')"
                                                        class="block w-full px-3 py-2 text-left text-sm text-gray-400 hover:bg-gray-50 cursor-pointer"
                                                    >
                                                        -- Pilih Jabatan --
                                                    </button>

                                                    <template
                                                        v-for="grup in opsiGrupJabatan"
                                                        :key="grup.label || 'tanpa-grup'"
                                                    >
                                                        <p
                                                            v-if="tampilkanJudulGrup && grup.label"
                                                            class="sticky top-0 z-10 border-y border-gray-100 bg-gray-50 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-gray-400"
                                                        >
                                                            {{ grup.label }}
                                                        </p>
                                                        <button
                                                            v-for="j in grup.options"
                                                            :key="j"
                                                            type="button"
                                                            role="option"
                                                            :aria-selected="jabatanPilihan === j"
                                                            @click="pilihJabatan(j)"
                                                            :class="[
                                                                'flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm cursor-pointer hover:bg-indigo-50 hover:text-indigo-700',
                                                                jabatanPilihan === j
                                                                    ? 'bg-indigo-50 font-semibold text-indigo-700'
                                                                    : 'text-gray-700',
                                                            ]"
                                                        >
                                                            <span class="break-words">{{ j }}</span>
                                                            <svg
                                                                v-if="jabatanPilihan === j"
                                                                class="h-4 w-4 flex-shrink-0"
                                                                viewBox="0 0 20 20"
                                                                fill="currentColor"
                                                            >
                                                                <path
                                                                    fill-rule="evenodd"
                                                                    d="M16.704 5.29a1 1 0 010 1.415l-7.5 7.5a1 1 0 01-1.415 0l-3.5-3.5a1 1 0 111.415-1.415L8.5 12.086l6.793-6.793a1 1 0 011.415 0z"
                                                                    clip-rule="evenodd"
                                                                />
                                                            </svg>
                                                        </button>
                                                    </template>

                                                    <!-- Opsi ketik sendiri -->
                                                    <button
                                                        type="button"
                                                        role="option"
                                                        :aria-selected="jabatanPilihan === OPSI_BARU"
                                                        @click="pilihJabatan(OPSI_BARU)"
                                                        :class="[
                                                            'block w-full border-t border-gray-100 px-3 py-2 text-left text-sm cursor-pointer hover:bg-indigo-50 hover:text-indigo-700',
                                                            jabatanPilihan === OPSI_BARU
                                                                ? 'bg-indigo-50 font-semibold text-indigo-700'
                                                                : 'text-gray-700',
                                                        ]"
                                                    >
                                                        Lainnya (ketik sendiri)...
                                                    </button>
                                                </div>
                                            </div>

                                            <input
                                                v-if="jabatanPilihan === OPSI_BARU"
                                                type="text"
                                                v-model="jabatanTeks"
                                                required
                                                placeholder="Ketik jabatan yang belum ada di daftar"
                                                :class="inputClass('jabatan')"
                                            />

                                            <button
                                                v-if="perluAwalan && fungsionalBawaan"
                                                type="button"
                                                @click="kembaliKeBawaan"
                                                class="mt-1 text-xs text-indigo-600 hover:text-indigo-800 cursor-pointer"
                                            >
                                                &laquo; Kembali ke jabatan otomatis
                                            </button>
                                        </template>
                                    </template>

                                    <p
                                        v-if="form.errors.jabatan"
                                        class="mt-1 text-xs text-red-600"
                                    >
                                        {{ form.errors.jabatan }}
                                    </p>
                                </div>

                                <div class="mt-4 md:w-1/3">
                                    <label
                                        class="block text-sm font-medium text-gray-700"
                                        >Status Kepegawaian <span class="text-red-500">*</span></label
                                    >
                                    <select
                                        v-model="form.status_aktif"
                                        required
                                        :class="inputClass('status_aktif')"
                                    >
                                        <option v-for="status in daftarStatus" :key="status" :value="status">{{ status }}</option>
                                    </select>
                                    <p
                                        v-if="form.errors.status_aktif"
                                        class="mt-1 text-xs text-red-600"
                                    >
                                        {{ form.errors.status_aktif }}
                                    </p>
                                </div>
                            </div>

                            <div
                                v-if="isEditMode"
                                class="mt-4 flex items-start gap-2 rounded-lg border border-blue-100 bg-blue-50/60 p-3"
                            >
                                <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke-width="1.5"
                                    stroke="currentColor"
                                    class="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"
                                    />
                                </svg>
                                <p class="text-xs text-blue-700 leading-relaxed">
                                    Untuk mengubah kuota/saldo cuti pegawai ini
                                    (hak tahunan, sisa cuti, atau cuti
                                    ditangguhkan), buka menu
                                    <span class="font-semibold"
                                        >Rekap Kuota Detail</span
                                    >
                                    lalu klik
                                    <span class="font-semibold"
                                        >Kelola Kuota</span
                                    >
                                    pada baris pegawai terkait.
                                </p>
                            </div>

                            <div
                                class="flex justify-end space-x-2 mt-6 pt-4 border-t border-gray-100"
                            >
                                <button
                                    type="button"
                                    @click="closeModal"
                                    class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 cursor-pointer transition"
                                >
                                    Batal
                                </button>
                                <button
                                    type="submit"
                                    class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 cursor-pointer transition disabled:opacity-50 disabled:cursor-not-allowed"
                                    :disabled="form.processing"
                                >
                                    {{
                                        form.processing
                                            ? "Menyimpan..."
                                            : isEditMode
                                              ? "Simpan Perubahan"
                                              : "Simpan Data"
                                    }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </Teleport>

            <!-- ========================================== -->
            <!-- MODAL IMPOR DATA PEGAWAI                   -->
            <!-- ========================================== -->
            <Teleport to="body">
                <div
                    v-if="isImportModalOpen"
                    class="fixed inset-0 flex items-end justify-center p-0 sm:items-center sm:p-4"
                    style="z-index: 999999"
                >
                    <div
                        class="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        @click="closeImportModal"
                    ></div>

                    <div
                        class="relative bg-white p-4 sm:p-6 rounded-t-2xl sm:rounded-xl w-full max-w-md shadow-2xl max-h-[90dvh] overflow-y-auto z-10"
                    >
                        <div
                            class="flex justify-between items-center mb-5 border-b pb-3"
                        >
                            <h3 class="text-lg font-bold text-gray-800">
                                Impor Data Pegawai
                            </h3>
                            <button
                                type="button"
                                @click="closeImportModal"
                                class="text-gray-400 hover:text-red-500 font-bold text-2xl cursor-pointer outline-none"
                            >
                                &times;
                            </button>
                        </div>

                        <form @submit.prevent="submitImportForm">
                            <p class="text-sm text-gray-500 mb-4">
                                Unggah file Excel (.xlsx) atau CSV berisi data
                                pegawai untuk ditambahkan secara massal.
                            </p>

                            <div class="mb-2">
                                <label
                                    class="block text-sm font-medium text-gray-700 mb-1"
                                    >File Excel / CSV</label
                                >
                                <input
                                    ref="importFileInput"
                                    type="file"
                                    accept=".xlsx,.xls,.csv"
                                    @change="handleImportFileChange"
                                    class="block w-full text-sm text-gray-600 border border-gray-300 rounded-md cursor-pointer focus:outline-none file:mr-3 file:py-2 file:px-4 file:border-0 file:bg-blue-50 file:text-blue-700 file:font-semibold hover:file:bg-blue-100"
                                />
                            </div>

                            <p
                                v-if="importForm.errors.file"
                                class="text-sm text-red-600 mb-2"
                            >
                                {{ importForm.errors.file }}
                            </p>

                            <p class="text-xs text-gray-400 mb-5">
                                Pastikan kolom pada file mengikuti format
                                template yang sudah ditentukan (NIP, Nama,
                                Kelompok Substansi, Tim Kerja, Jabatan, Role,
                                dsb).
                            </p>

                            <div
                                class="flex justify-end space-x-2 pt-4 border-t border-gray-100"
                            >
                                <button
                                    type="button"
                                    @click="closeImportModal"
                                    class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 cursor-pointer transition"
                                >
                                    Batal
                                </button>
                                <button
                                    type="submit"
                                    class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 cursor-pointer transition disabled:opacity-50 disabled:cursor-not-allowed"
                                    :disabled="
                                        importForm.processing ||
                                        !importForm.file
                                    "
                                >
                                    {{
                                        importForm.processing
                                            ? "Mengunggah..."
                                            : "Impor Sekarang"
                                    }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </Teleport>

            <!-- TOAST NOTIFIKASI RESET PASSWORD -->
            <Teleport to="body">
                <Transition
                    enter-active-class="transition ease-out duration-200"
                    enter-from-class="opacity-0 translate-y-2"
                    enter-to-class="opacity-100 translate-y-0"
                    leave-active-class="transition ease-in duration-150"
                    leave-from-class="opacity-100 translate-y-0"
                    leave-to-class="opacity-0 translate-y-2"
                >
                    <div
                        v-if="showResetToast"
                        class="fixed bottom-6 right-6 flex items-center gap-3 bg-white border border-green-200 shadow-2xl rounded-lg px-4 py-3 max-w-sm"
                        style="z-index: 999999"
                    >
                        <span
                            class="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-green-100"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                class="h-5 w-5 text-green-600"
                                viewBox="0 0 20 20"
                                fill="currentColor"
                            >
                                <path
                                    fill-rule="evenodd"
                                    d="M16.704 5.29a1 1 0 010 1.415l-7.5 7.5a1 1 0 01-1.415 0l-3.5-3.5a1 1 0 111.415-1.415L8.5 12.086l6.793-6.793a1 1 0 011.415 0z"
                                    clip-rule="evenodd"
                                />
                            </svg>
                        </span>
                        <div class="text-sm">
                            <p class="font-semibold text-gray-800">
                                Kata sandi berhasil diatur ulang
                            </p>
                            <p class="text-gray-500">
                                Akun
                                <span class="font-medium">{{
                                    resetToastNama
                                }}</span>
                                sekarang menggunakan password default.
                            </p>
                        </div>
                        <button
                            type="button"
                            @click="showResetToast = false"
                            class="ml-2 text-gray-400 hover:text-gray-600 cursor-pointer"
                        >
                            &times;
                        </button>
                    </div>
                </Transition>
            </Teleport>

            <!-- TOAST NOTIFIKASI ERROR (reset password / hapus gagal) -->
            <Teleport to="body">
                <Transition
                    enter-active-class="transition ease-out duration-200"
                    enter-from-class="opacity-0 translate-y-2"
                    enter-to-class="opacity-100 translate-y-0"
                    leave-active-class="transition ease-in duration-150"
                    leave-from-class="opacity-100 translate-y-0"
                    leave-to-class="opacity-0 translate-y-2"
                >
                    <div
                        v-if="showErrorToast"
                        class="fixed bottom-6 right-6 flex items-center gap-3 bg-white border border-red-200 shadow-2xl rounded-lg px-4 py-3 max-w-sm"
                        style="z-index: 999999"
                        role="alert"
                    >
                        <span
                            class="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-red-100"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                class="h-5 w-5 text-red-600"
                                viewBox="0 0 20 20"
                                fill="currentColor"
                            >
                                <path
                                    fill-rule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                                    clip-rule="evenodd"
                                />
                            </svg>
                        </span>
                        <div class="text-sm">
                            <p class="font-semibold text-gray-800">
                                Aksi gagal
                            </p>
                            <p class="text-gray-500">
                                {{ errorToastMessage }}
                            </p>
                        </div>
                        <button
                            type="button"
                            @click="showErrorToast = false"
                            class="ml-2 text-gray-400 hover:text-gray-600 cursor-pointer"
                        >
                            &times;
                        </button>
                    </div>
                </Transition>
            </Teleport>

            <!-- ========================================== -->
            <!-- CUSTOM MODAL KONFIRMASI HAPUS              -->
            <!-- ========================================== -->
            <Teleport to="body">
                <Transition
                    enter-active-class="transition ease-out duration-200"
                    enter-from-class="opacity-0"
                    enter-to-class="opacity-100"
                    leave-active-class="transition ease-in duration-150"
                    leave-from-class="opacity-100"
                    leave-to-class="opacity-0"
                >
                    <div
                        v-if="showModalHapus"
                        class="fixed inset-0 z-[999999] flex items-end justify-center overflow-y-auto overflow-x-hidden bg-slate-900/50 backdrop-blur-sm sm:items-center"
                    >
                        <div class="absolute inset-0" @click="batalHapus"></div>

                        <div class="relative w-full max-w-md">
                            <div
                                class="relative max-h-[90dvh] overflow-y-auto rounded-t-2xl bg-white p-5 text-center shadow-2xl sm:rounded-2xl sm:p-6"
                            >
                                <div
                                    class="mx-auto flex items-center justify-center h-14 w-14 rounded-full bg-red-50 mb-5"
                                >
                                    <svg
                                        class="h-7 w-7 text-red-600"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke-width="2"
                                        stroke="currentColor"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                        />
                                    </svg>
                                </div>

                                <h3
                                    class="mb-2 text-lg font-bold text-slate-800"
                                >
                                    Konfirmasi Hapus
                                </h3>

                                <p class="mb-3 text-sm text-slate-500">
                                    Apakah Anda yakin ingin menghapus pegawai
                                    ini?
                                </p>

                                <div
                                    class="mb-5 p-3 bg-slate-50 border border-slate-100 rounded-lg"
                                >
                                    <p
                                        class="text-sm font-extrabold text-slate-700"
                                    >
                                        {{ pegawaiYangAkanDihapus?.nama }}
                                    </p>
                                </div>

                                <p
                                    class="mb-6 text-[13px] text-slate-400 leading-relaxed"
                                >
                                    Akses login akan dicabut, namun riwayat cuti
                                    tetap aman sebagai arsip.
                                </p>

                                <div class="grid grid-cols-2 gap-3">
                                    <button
                                        @click="batalHapus"
                                        type="button"
                                        class="px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                                    >
                                        Batal
                                    </button>
                                    <button
                                        @click="eksekusiHapus"
                                        type="button"
                                        class="px-4 py-2.5 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer"
                                    >
                                        Ya, Hapus
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </Transition>
            </Teleport>

            <!-- ========================================== -->
            <!-- CUSTOM MODAL KONFIRMASI RESET PASSWORD     -->
            <!-- ========================================== -->
            <Teleport to="body">
                <Transition
                    enter-active-class="transition ease-out duration-200"
                    enter-from-class="opacity-0"
                    enter-to-class="opacity-100"
                    leave-active-class="transition ease-in duration-150"
                    leave-from-class="opacity-100"
                    leave-to-class="opacity-0"
                >
                    <div
                        v-if="showModalReset"
                        class="fixed inset-0 z-[999999] flex items-end justify-center overflow-y-auto overflow-x-hidden bg-slate-900/50 backdrop-blur-sm sm:items-center"
                    >
                        <div class="absolute inset-0" @click="batalReset"></div>

                        <div class="relative w-full max-w-md">
                            <div
                                class="relative max-h-[90dvh] overflow-y-auto rounded-t-2xl bg-white p-5 text-center shadow-2xl sm:rounded-2xl sm:p-6"
                            >
                                <div
                                    class="mx-auto flex items-center justify-center h-14 w-14 rounded-full bg-orange-50 mb-5"
                                >
                                    <svg
                                        class="h-7 w-7 text-orange-600"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke-width="2"
                                        stroke="currentColor"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z"
                                        />
                                    </svg>
                                </div>

                                <h3
                                    class="mb-2 text-lg font-bold text-slate-800"
                                >
                                    Atur Ulang Kata Sandi
                                </h3>

                                <p class="mb-3 text-sm text-slate-500">
                                    Apakah Anda yakin ingin mereset password
                                    pegawai ini?
                                </p>

                                <div
                                    class="mb-5 p-3 bg-slate-50 border border-slate-100 rounded-lg"
                                >
                                    <p
                                        class="text-sm font-extrabold text-slate-700"
                                    >
                                        {{ pegawaiYangAkanDireset?.nama }}
                                    </p>
                                </div>

                                <p
                                    class="mb-6 text-[13px] text-slate-400 leading-relaxed"
                                >
                                    Kata sandi akan diubah menjadi kata sandi bawaan
                                    <span class="font-bold text-slate-600"
                                        >password123</span
                                    >. Pegawai wajib menggantinya saat login
                                    berikutnya.
                                </p>

                                <div class="grid grid-cols-2 gap-3">
                                    <button
                                        @click="batalReset"
                                        type="button"
                                        class="px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                                    >
                                        Batal
                                    </button>
                                    <button
                                        @click="eksekusiReset"
                                        type="button"
                                        class="px-4 py-2.5 text-sm font-semibold text-white bg-orange-500 hover:bg-orange-600 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer"
                                    >
                                        Ya, Reset
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </Transition>
            </Teleport>
        </div>
    </MainLayout>
</template>
